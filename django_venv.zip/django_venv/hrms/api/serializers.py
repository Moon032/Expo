from rest_framework import serializers
from api.models import Employee

class EmployeeSerializers(serializers.ModelSerializer):

    class  Meta:
        model = Employee
        fields = ['id', 'name', 'phone', 'address','image','birthday','created_date']
        