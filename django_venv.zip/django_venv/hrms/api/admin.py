from django.contrib import admin
from api.models import Employee
# Register your models here.
admin.site.register(Employee)