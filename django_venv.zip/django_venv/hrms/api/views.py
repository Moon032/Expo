from django.shortcuts import render

# Create your views here.
from rest_framework import viewsets
from api.models import Employee
from api.serializers import EmployeeSerializers
from rest_framework.authentication import TokenAuthentication

class EmployeeViewSet(viewsets.ModelViewSet):
    serializer_class = EmployeeSerializers
    queryset = Employee.objects.all()
    authentication_classes = (TokenAuthentication,)