import { Alert, Image, Platform, StatusBar, StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import { useState, useEffect, useRef } from "react";
import { RouteUrl } from "../Components/Endpoint";
import AsyncStorage from '@react-native-async-storage/async-storage';
import { AlertDialog, Button } from "native-base";

function Login(props){

    const [ user, setUser] = useState({username: "", password:""})
    const [ isLoading, setIsLoading ] = useState(false)
    const [ isModel, setIsModel ] = useState(false)
    const [ errorContent , setErrorContent] = useState({})
    const cancelRef = useRef(null);

    const storeData = async (name, value) => {
        try {
          await AsyncStorage.setItem(name, value)
        } catch (e) {
          console.log(e)
        }
      }

    const clickLogin = () => {
        if(user.username == "" || user.password == ""){
            setErrorContent({title: "Require Error", body: "Username or Passowrd is required !"})
            setIsModel(true)
        }
        else{
            setIsLoading(true)
            fetch(`${RouteUrl.login}`, {
                method: 'POST', 
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(user)
            })
            .then( resp => resp.json())
            .then( res => {
                if(res.token){
                    storeData('hrms-token', res.token);
                    setIsLoading(false)
                    props.navigation.navigate('drawer')
                }else{
                    setIsLoading(false)
                    setErrorContent({title: "Incorrect",body:"Username or Password incorrect !"})
                    setIsModel(true)
                }
            })
            .catch( error => {Alert.alert('Internal Server Error'),setIsLoading(false)})
        }

    }

    const handleChange = (name, value) => {
        newUser = {...user}
        newUser[name] = value
        setUser(newUser)
        console.log(user)
    }

    useEffect(()=>{
        const unsubscribe = props.navigation.addListener('focus', () => {
            setUser({username: "", password:""})
        });
        return unsubscribe
    },[])

    return(
        <>
        <StatusBar/>
        <View style={styles.container} pointerEvents={isLoading ? 'none' : 'auto'}>           

            <View style={styles.inputView}> 
                <TextInput style={styles.inputText} value={user.username} placeholder="Username" onChangeText={(value)=>handleChange('username',value)}/>
            </View>
            <View style={styles.inputView}> 
                <TextInput style={styles.inputText} value={user.password} placeholder="Password" onChangeText={(value)=>handleChange('password',value)} secureTextEntry={true} />
            </View>
            <TouchableOpacity>
                <Text onPress={()=>props.navigation.navigate('register')} style={styles.signup}> Create New Account ?</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.login} disabled={isLoading} onPress={clickLogin}> 
                <Text> {isLoading ? "Loading ..." : "Log In"} </Text>
            </TouchableOpacity> 
            
        </View>

        <AlertDialog leastDestructiveRef={cancelRef} isOpen={isModel} onClose={() => setIsModel(false)}>
        <AlertDialog.Content>
          <AlertDialog.CloseButton />
          <AlertDialog.Header>{errorContent.title}</AlertDialog.Header>
          <AlertDialog.Body>
            {errorContent.body}
          </AlertDialog.Body>
        </AlertDialog.Content>
      </AlertDialog>


        </>
); }


const styles = StyleSheet.create({ 
    container: {
        width: `100%`,
        height: `100%`,
        flex: 1, 
        backgroundColor: `#052F83`, 
        alignItems: "center",
        justifyContent: "center", 
    },
    Union: {
        position: `absolute`,
        marginTop:20,
        marginLeft:20,
    },
    title: {
        fontSize:60,
        color:'black',
        marginLeft:90,
        marginTop:5,
        marginBottom:100,
      },
    Rectangle: {
        height: `100%`,
        width: `100%`,
        position: `absolute`,
    },
    image: { 
        marginBottom: 40, 
        width: 100,
        height: 100
    },
    inputView: {
        backgroundColor: Platform.OS == "android" ? "#007099" : "orange",
        borderRadius: 30,
        width: "70%",
        height: 45,
        marginBottom: 20,
    },
    inputText: { 
        height: 50,
        padding: 10,
        marginLeft: 20, 
    },
    signup: {
        height: 20, 
        marginBottom: 20,
    },
    login: {
        width: "70%",
        height: 50,
        alignItems: "center", 
        justifyContent: "center", 
        marginTop: 40, 
        backgroundColor: "#008990",
    }, 
    lottie: {
        width: 100,
        height: 100,
      },
});

export default Login