import { useEffect, useState } from "react";
import { Button, FlatList, Image, SafeAreaView, StyleSheet, Text, View } from "react-native";
import { FloatingAction } from "react-native-floating-action";
import { RouteUrl } from "../Components/Endpoint";
import Icon from 'react-native-vector-icons/FontAwesome';
import AsyncStorage from '@react-native-async-storage/async-storage';


function EmployeesList(props){

    const [fetchData, setFetchData] = useState(null)
    const [isRefreshing, setIsRefreshing] = useState(false)
    const [token, setToken] = useState(null)

    const onRefresh = () => {
        setIsRefreshing(true)
        
        setTimeout(()=>{
            fetchEmployee()
            setIsRefreshing(false)
        },900)
    }

    const fetchEmployee = async () => {
        const value = await AsyncStorage.getItem('hrms-token')
        setToken(value)
        console.log('data fetch',value)
        fetch(`${RouteUrl.employee}`, {
            method: 'GET', 
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Token ${value}` }
        })
        .then( resp => resp.json())
        .then( res => setFetchData(res)) 
        .catch( error => console.log(error))
    }

    

    useEffect(()=>{
        const unsubscribe = props.navigation.addListener('focus', () => {
            fetchEmployee()
        });
        return unsubscribe
    },[])

    return(
        <SafeAreaView style={styles.container}>
            
            { fetchData !== null ? (
                
                <FlatList
                data={fetchData}
                onRefresh={onRefresh} 
                refreshing={isRefreshing}
                renderItem={({item})=>(
                    <View >
                    { isRefreshing ? (
                        <Text>Skeletoron</Text>
                    ):(
                        <View style={styles.row}>
                        <Text onPress={()=>{props.navigation.navigate('detail',{item:item ,token:token})}}>
                            <View>
                                { item.image ? (
                                    <Image style={styles.image} source={{uri: item.image}}/>
                                ):(
                                    <Image style={styles.image} source={require("../assets/images/Luna.png")}/>
                                )}           
                            </View>
                            <View>
                                <Text >{item.name}</Text>
                                <Text > {item.phone} </Text>
                            </View>
                        </Text>
                    </View>
                    )}
                    </View>

                )}
            />
            ) : (
                <View style={{flex:1, justifyContent:"center", alignItems: "center"}}>
                    <Text style={{fontWeight: "bold",fontSize: 20}}>
                        Please Check Your Connection !!
                    </Text>
                </View>
            )}
            

            <FloatingAction 
                onPressMain={()=>{props.navigation.navigate('form',{update: false,token: token})}}
            />

        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    container: {
        width: "100%",
        height: "100%",
        backgroundColor: "#rgb(218,225,226)"
    },
    image: {
        width: 60,
        height: 60,
        borderRadius: 60/2
    },
    col: {
        flex: 1,
        flexDirection: "column"
    },
    row: {
        flex: 1,
        flexDirection: "row",
        marginVertical: 10,
        marginHorizontal: 10,
        backgroundColor: "#fff",
        borderRadius: 10
    },

})

export default EmployeesList