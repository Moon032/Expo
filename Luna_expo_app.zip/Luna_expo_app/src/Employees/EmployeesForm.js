import { Alert, Button, Image, ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { TextInput } from "react-native-gesture-handler";
import { useState, useEffect } from "react";
import { RouteUrl } from "../Components/Endpoint";
import DateTimePickerModal from "react-native-modal-datetime-picker";
import moment from 'moment';
import * as ImagePicker from 'expo-image-picker';
import myanmarPhoneNumber from "myanmar-phonenumber";
import AsyncStorage from "@react-native-async-storage/async-storage";

function EmployeesForm(props){

    const [data, setData] = useState({})

    const [isLoading, setIsLoading] = useState(false)
    const [isDatePicker, setDatePicker] = useState(false);
    const [isDateTimePicker, setDateTimePicker] = useState(false);
    const [token, setToken ] = useState(null)

    const OnClick = () => {
        if(data.name==""){
            Alert.alert("Username is Required !")
        }
        else if(data.phone==""){
            Alert.alert("Phone is Required !")
        }
        else if(!isNaN(data.phone)==false){
            Alert.alert("Phone is not number !")
        }
        else if(!myanmarPhoneNumber.isValidMMPhoneNumber(data.phone)){
            Alert.alert("Phone is Invalid, Please input myanmar number ?")
        }
        else if(data.address==""){
            Alert.alert("Address is Required !")
        }
        else if(data.birthday==""){
            Alert.alert("Birthday is Required !")
        }
        else if(data.created_date==""){
            Alert.alert("Created Date is Required !")
        }
        else{
            props.route.params.update ? UpdateFetch() : CreateFetch()
        }

    }

    const CreateFetch = () => {
        console.log('create',data)
        fetch(`${RouteUrl.employee}`, {
            method: 'POST', 
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Token ${token}` 
            },
            body: JSON.stringify(data)
        })
        .then( res => { 
            if(res.status==400){
                Alert.alert(" Bad Request Error")
            }
            else if(res.status==500){
                Alert.alert(" Internal Server Error")
            }
            else if(res.status==201){
                props.navigation.navigate('list')
            }
        }) 
        .catch( error => console.log(error))
    }

    const UpdateFetch = () => {
        delete data["image"]
        console.log('update',data)
        fetch(`${RouteUrl.employee}${data.id}/`, {
            method: 'PUT', 
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Token ${token}` 
            },
            body: JSON.stringify(data)
        })
        .then( res => {
            props.navigation.navigate('list')
        }) 
        .catch( error => console.log(error))
    }

    const onChangeInput = (name, value) => {
        newData = { ...data }
        newData[name] = value
        setData(newData)
    }

    const pickImage = async () => {
        // launchCameraAsync()
        let result = await ImagePicker.launchImageLibraryAsync({
          mediaTypes: ImagePicker.MediaTypeOptions.All,
          allowsEditing: true,
          aspect: [4, 4],
          quality: 1,
        });
        if(!result.canceled) {
          onChangeInput('image',{uri: result.assets[0].uri, name: 'photo.png', filename :'imageName.png', type: 'image/png'})
        }
    };

    useEffect(()=>{
        console.log('useffect call')
        setToken(AsyncStorage.getItem('hrms-token'))
        const unsubscribe = props.navigation.addListener('focus', () => {
            if(props.route.params.data!=undefined){
                setData(props.route.params.data)
                setToken(props.route.params.token)
            }
            else{
                now = new Date()
                setData({name:"",phone:"",address:"",birthday:"",created_date:now.toJSON()})
                setToken(props.route.params.token)
            }
          });
        return unsubscribe
    },[])

    return(
        <ScrollView>
            <TextInput style={styles.input} value={data.name} onChangeText={(value)=>onChangeInput('name',value)} placeholder="name" />
            <TextInput style={styles.input} value={data.phone} onChangeText={(value)=>onChangeInput('phone',value)} placeholder="phone" />
            <TextInput style={styles.input} value={data.address} onChangeText={(value)=>onChangeInput('address',value)} placeholder="address" />

            <Text style={[styles.input,{paddingVertical:8}]} value={data.birthday} onPress={()=>setDatePicker(true)} placeholder="address">
                <Text style={{color:"gray"}}> {data.birthday=="" ? 'birthday': data.birthday } </Text>
            </Text> 

            <Text style={[styles.input,{paddingVertical:8}]} value={data.created_date} onPress={()=>setDateTimePicker(true)} placeholder="address">
                <Text style={{color:"gray"}}> {data.created_date=="" ? 'created date': data.created_date } </Text>
            </Text> 
     
            <DateTimePickerModal
                isVisible={isDatePicker}
                mode="date"
                onConfirm={(v)=>{onChangeInput('birthday',v.toISOString().slice(0, 10)),setDatePicker(false)}}
                onCancel={()=>setDatePicker(false)}
            />
            <DateTimePickerModal
                isVisible={isDateTimePicker}
                mode="datetime"
                onConfirm={(v)=>{onChangeInput('created_date',v.toJSON()),setDateTimePicker(false)}}
                onCancel={()=>setDateTimePicker(false)}
            />
    
            <TouchableOpacity onPress={pickImage} style={{alignItems: "center" }}>
                {data.image!=null?
                <Image source={{ uri: data.image.uri }} style={{ width: 150, height: 150}} /> :
                <Image source={require("../assets/images/Luna.png")} style={{ width: 150, height: 150}} />
                }
            <Text onPress={()=>onChangeInput('image',{})} style={styles.button2}>Cancle</Text>
            </TouchableOpacity>
            
            <TouchableOpacity onPress={OnClick} style={styles.button} >
                <Text style={styles.buttonName}> {props.route.params.update ? 'Update' : 'Create'} </Text>
            </TouchableOpacity>

        </ScrollView>
    )
}

const styles = StyleSheet.create({
    container: {
        width: "100%",
        height: "100%"
    },
    input : {
        width: "70%",
        height: 40,
        paddingHorizontal: 24,
        marginVertical: 20,
        marginHorizontal: 30,
        backgroundColor: "#fff",
        fontWeight: "bold",
        borderRadius: 20
    },
    row : {
        flex: 1,
        flexDirection: "row"
    },
    button: {
        width: "50%",
        height: 40,
        backgroundColor: "red",
        marginHorizontal: 100,
        marginVertical: 30,
        borderRadius: 30
    },
    buttonName: {
        paddingHorizontal: 68,
        paddingVertical: 10,
        color: "#fff"
    },
    button2: {
        width: "20%",
        height: 30,
        backgroundColor: "red",
        borderRadius: 30,
        color: "white",
        paddingHorizontal: 17,
        paddingVertical: 4,
        marginTop: 3
    }
})

export default EmployeesForm

