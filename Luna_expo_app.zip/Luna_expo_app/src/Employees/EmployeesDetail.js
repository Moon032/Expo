import { Button, Image, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { useEffect } from "react";
import { RouteUrl } from "../Components/Endpoint";


function EmployeesDetail(props){

    const data = props.route.params.item
    const token = props.route.params.token

    const deleteClick = () => {
        fetch(`${RouteUrl.employee}${data.id}/`, {
            method: 'DELETE', 
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Token ${token}` }
        })
        .then( res => props.navigation.navigate('list')) 
        .catch( error => console.log(error))
    }


    return(
        <View style={styles.container}>
            <View style={styles.imageCon}>
                {
                    data.image ? <Image style={styles.image} source={{uri: data.image}}/> :
                                <Image style={styles.image} source={require("../assets/images/Luna.png")}/>
                }
                
            </View>
            <View style={styles.textCon}>
                <Text style={styles.text}>Name - {data.name}</Text>
                <Text style={styles.text}>Phone - {data.phone} </Text>
                <Text style={styles.text}>Address - {data.address} </Text>
                <Text style={styles.text}>Birthday - {data.birthday} </Text>
                <Text style={styles.text}>Created_date - {data.created_date} </Text>
            </View>
            <View style={styles.row}>
                <TouchableOpacity onPress={()=>{props.navigation.goBack()}} style={styles.button}>
                    <Text style={styles.buttonText}  >Back</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={()=>{props.navigation.navigate('form',{data:data,update:true,token:token})}} style={styles.button}>
                    <Text style={styles.buttonText}>Update</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={deleteClick} style={[styles.button,{backgroundColor: "red"}]}>
                    <Text style={[styles.buttonText,{color: "#fff"}]}>Delete</Text>
                </TouchableOpacity>
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex:1,
        
    },
    imageCon: {
        paddingHorizontal: 93,
        paddingTop: 10
    },
    image: {
        width: 200,
        height: 200,
        borderRadius: 200/2
    },
    textCon: {
        paddingHorizontal: 30,
        paddingTop: 20,
    },
    text: {
        fontWeight: "bold",
        paddingTop: 40,
        fontSize: 20
    },
    row: {
        flex: 1,
        flexDirection: "row"
    },
    button: {
        width: 105,
        height: 40,
        backgroundColor: "orange",
        marginLeft: 12,
        marginTop: 20,
        borderRadius: 20
    },
    buttonText: {
        paddingVertical: 8,
        paddingHorizontal: 30
    }
})

export default EmployeesDetail