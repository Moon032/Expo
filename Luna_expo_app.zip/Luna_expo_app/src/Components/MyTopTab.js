import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
import EmployeesList from '../Employees/EmployeesList';
import EmployeesDetail from '../Employees/EmployeesDetail';
import EmployeesForm from '../Employees/EmployeesForm';

const Tab = createMaterialTopTabNavigator();

function MyTopTab() {
  return (
    <Tab.Navigator>
      <Tab.Screen name="list" component={EmployeesList} />
      <Tab.Screen name="detail" component={EmployeesDetail} />
      <Tab.Screen name="form" component={EmployeesForm} />
    </Tab.Navigator>
  );
}

export default MyTopTab