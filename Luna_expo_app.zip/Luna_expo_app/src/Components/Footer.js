import { Alert, Button, Text, TextInput, View } from 'react-native'
import React, { Component } from 'react'

class Footer extends Component {

    state = {
        name: ''
    }

    setName = (e) => {
        this.setState({name: e})
    }

    logConsole = () => {
        Alert.alert('Your name is ' + this.state.name )
    }

  render() {

    return (
      <View>
        <Text> Footer </Text>
        <TextInput onChangeText={this.setName} style={{backgroundColor: 'orange'}}/>
        <Button onPress={this.logConsole} title='Click'/>
      </View>
    )
  }
}

export default Footer