import { createDrawerNavigator } from '@react-navigation/drawer';
import EmployeesList from "../Employees/EmployeesList";
import EmployeesForm from "../Employees/EmployeesForm";
import EmployeesDetail from "../Employees/EmployeesDetail";
import Icon from 'react-native-vector-icons/FontAwesome';
import CustomDrawer from './CustomDrawer';

const Drawer = createDrawerNavigator();
// npm install @react-navigation/drawer
// npx expo install react-native-gesture-handler react-native-reanimated
function MyDrawer() {
  return (
    <Drawer.Navigator
      drawerContent={(props) => <CustomDrawer {...props} />}
      initialRouteName="list"
      screenOptions={{
        drawerActiveBackgroundColor: 'orange',
        drawerActiveTintColor: 'red',
        drawerInactiveBackgroundColor: 'green',
        drawerInactiveTintColor: 'blue',
        drawerLabelStyle: {
          marginLeft: 25,  
          fontSize: 15
        }
      }}
    >
      <Drawer.Screen name="list" component={EmployeesList}/>
    </Drawer.Navigator>
  );
}

export default MyDrawer