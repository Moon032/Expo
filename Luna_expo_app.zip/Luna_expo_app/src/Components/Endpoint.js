const Url = 'http://192.168.100.3:8000'

export const RouteUrl = {
    login: `${Url}/auth/`,
    employee: `${Url}/api/employees/`
}