import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import EmployeesList from '../Employees/EmployeesList';
import EmployeesDetail from '../Employees/EmployeesDetail';
import EmployeesForm from '../Employees/EmployeesForm';

const Tab = createBottomTabNavigator();

function MyBottonTab() {
  return (
    <Tab.Navigator>
      <Tab.Screen name="list" component={EmployeesList} />
      <Tab.Screen name="detail" component={EmployeesDetail} />
      <Tab.Screen name="form" component={EmployeesForm} />
    </Tab.Navigator>
  );
}

export default MyBottonTab