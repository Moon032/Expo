import { FlatList, Text, View } from "react-native";

function Header(props){
    return(
        <View>
            <Text> Header </Text>
            <FlatList
                data={[
                    {name:'Mg Mg'},{name:'Ko Ko'},{name:'Hla Hla'}
                ]}
                renderItem={({item})=>(
                        <Text>
                            <View>
                                <Text>{item.name}</Text>
                            </View>
                        </Text>
                    )
                }
            />
        </View>
    )
}

export default Header