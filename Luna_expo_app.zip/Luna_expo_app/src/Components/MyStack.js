import { View } from "react-native";
import EmployeesList from "../Employees/EmployeesList";
import EmployeesForm from "../Employees/EmployeesForm";
import EmployeesDetail from "../Employees/EmployeesDetail";
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';
import Login from "../Login/Login";
import MyDrawer from "./MyDrawer";
import MyBottonTab from "./MyBottonTab";
import MyTopTab from "./MyTopTab";

const Stack = createStackNavigator();


function MyStack(){
    return(
        <NavigationContainer>
            <Stack.Navigator
                initialRouteName="login"
                screenOptions={{
                    headerMode: 'screen',
                    headerTintColor: 'white',
                    headerStyle: { backgroundColor: 'tomato' },
                  }}
            >
                <Stack.Screen name="login" options={{headerShown: false}} component={Login} />
                <Stack.Screen name="list" component={EmployeesList} />
                <Stack.Screen name="form" component={EmployeesForm} />
                <Stack.Screen name="detail" component={EmployeesDetail} />
                <Stack.Screen name="drawer" options={{headerShown: false}} component={MyDrawer} />
                <Stack.Screen name="botton" options={{headerShown: false}} component={MyBottonTab} />
                <Stack.Screen name="top" options={{headerShown: false}} component={MyTopTab} />
            </Stack.Navigator>
        </NavigationContainer>
    )
}

export default MyStack