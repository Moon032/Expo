import { View, Text, ImageBackground, Image } from 'react-native'
import React from 'react'
import { DrawerContentScrollView, DrawerItem, DrawerItemList } from '@react-navigation/drawer'
import Icon from 'react-native-vector-icons/FontAwesome';

const CustomDrawer = (props) => {
  return (
    <View style={{flex:1}}>
      
          <ImageBackground 
            source={require('../assets/images/nightsky.jpeg')} 
            style={{paddingHorizontal: 20, paddingVertical: 25, marginTop: 30,}}
          >
            <Image
              source={require('../assets/images/Luna.png')} 
              style={{height:60, width:60, borderRadius: 60/2, marginBottom: 10}}
            />
            <Text style={{color: 'black', fontSize: 20, marginTop:10}}>Moon Lay</Text>
            <Text style={{color: 'black', fontSize: 12}}>littlemoonslittlemoons@gmail.com</Text>
          </ImageBackground>
          <View style={{flex: 1, backgroundColor: "#fff", paddingTop: 10}}>
            <DrawerItemList {...props} />
          </View>        
        
      </View>
  )
}

export default CustomDrawer