import { StatusBar } from 'expo-status-bar';
import { Alert, SafeAreaView, StyleSheet, Text, View } from 'react-native';
import 'react-native-gesture-handler';
import MyStack from './src/Components/MyStack';
import { NativeBaseProvider } from "native-base";

export default function App() {
  return (
      <NativeBaseProvider>
        <StatusBar backgroundColor = "blue" />
        <MyStack/>
      </NativeBaseProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 100,
  },
});


// 6_expo

// npx create-expo-app first_expo_app

// cd first_expo_app

// npx expo start


// android
  // play store
  // expo go

//ios
  // app store
  // expo go

// npm i
  // npm i --force

// npm i expo 
// npm i expo-status-bar



